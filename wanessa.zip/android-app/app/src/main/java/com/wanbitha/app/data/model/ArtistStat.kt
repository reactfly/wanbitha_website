package com.wanbitha.app.data.model

data class ArtistStat(
    val value: String,
    val label: String,
)
